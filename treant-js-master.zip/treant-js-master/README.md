<pre>
  _______                   _          _     
 |__   __|                 | |        (_)    
    | |_ __ ___  __ _ _ __ | |_ ______ _ ___ 
    | | '__/ _ \/ _` | '_ \| __|______| / __|
    | | | |  __/ (_| | | | | |_       | \__ \
    |_|_|  \___|\__,_|_| |_|\__|      | |___/
                                     _/ |    
                                    |__/     
</pre>

Treant-js is an SVG based JS library for drawing tree diagrams.
It relies on Raphael and jQuery for handling SVG and animations.

For Docs, Examples, and everything else see:
http://fperucic.github.io/treant-js
